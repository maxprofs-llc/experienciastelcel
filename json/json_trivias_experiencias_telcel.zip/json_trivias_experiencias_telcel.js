// dinamica
{
	"vigencia": "Dec. 14 | 2018", 
	"vigenciaUTC": "234525665655",
	"imagen": "http://telcelbk.atomyc.in/static/temps/promo_28_min.jpg", 
	"premio": "effgsdfgsdfgsdfgdsfgdsfgs", 
	"bases": "zdvzsfvgsfsfvsfs", 
	"imagen_lg": "http://telcelbk.atomyc.in/static/temps/promo_28_min.JPG", 
	"titulo": "hoalkamja trhdfghdfhdf"
	"shares": 120, 
	"likes": 340, 
	"dinamica": "trivia", 
	"pk": 28, 
	"preguntas":[
		{
			imagen: "http://sdfgsdfgsdfgdsfg",
			pregunta: "asdasdfasdfsadfasdf"
			opciones: {
				"a":"asdasdfasdfsadfasdf",
				"b":"asda dgbsdggsdfasdfsadfasdf",
				"c":"asdasdfasdfsad zdfdb fb fasdf",
			}
		}

		"preguntas":{
			imagen: "http://sdfgsdfgsdfgdsfg",
			pregunta: "asdasdfasdfsadfasdf"
			opciones: {
				"a":"asdasdfasdfsadfasdf",
				"b":"asda dgbsdggsdfasdfsadfasdf",
				"c":"asdasdfasdfsad zdfdb fb fasdf",
			}
		}

		"preguntas":{
			imagen: "http://sdfgsdfgsdfgdsfg"
			pregunta: "asdasdfasdfsadfasdf"
			opciones: {
				"a":"asdasdfasdfsadfasdf",
				"b":"asda dgbsdggsdfasdfsadfasdf",
				"c":"asdasdfasdfsad zdfdb fb fasdf",
			}
		}
	]


}


//respuesta

{	
	pk: 43,
	userid: 122334;
	status: "inicio"
}

{	
	pk: 43,
	userid: 122334;
	status: "fin"
	respuestas:[
		{ppk:2,rpk:34},
		{ppk:2,rpk:35},
		{ppk:2,rpk:31},			
	]
}

// tuviste 2 respuestas correctas de 3, tu tiempo de participacion fue 10 dias con 02:03:23.
// 10 horas con 12 min y 33 seg

// respuesta servidor

{
	pk: 43,
	userid: 122334;
	status: "fin"
	respuestas:[
		{ppk:2,rpk:34},
		{ppk:2,rpk:35},
		{ppk:2,rpk:31},			
	]
	correctas:"2"
	preguntastotales: "3"
	tiempojuego:"1234556666"
}


// card o tarjeta

{	
	"vigencia": "Dec. 14 | 2018", 
	"vigenciaUTC": "234525665655",
	"imagen": "http://telcelbk.atomyc.in/static/temps/promo_28_min.jpg", 
	"titulo": "hoalkamja"
	"titulo_color": "pasas", 
	"shares": 120, 
	"likes": 340, 
	"dinamica": "trivia", 
	"pk": 28, 
}

